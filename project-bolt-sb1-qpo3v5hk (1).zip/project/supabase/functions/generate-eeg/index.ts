import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface EEGParameters {
  baseFrequency: number;
  frequencyRange: [number, number];
  baseAmplitude: number;
  amplitudeRange: [number, number];
}

const EEG_PARAMETERS: Record<string, EEGParameters> = {
  delta: {
    baseFrequency: 2,
    frequencyRange: [0.5, 4],
    baseAmplitude: 40,
    amplitudeRange: [20, 100],
  },
  theta: {
    baseFrequency: 6,
    frequencyRange: [4, 8],
    baseAmplitude: 30,
    amplitudeRange: [15, 50],
  },
  alpha: {
    baseFrequency: 10,
    frequencyRange: [8, 13],
    baseAmplitude: 25,
    amplitudeRange: [10, 45],
  },
  beta: {
    baseFrequency: 20,
    frequencyRange: [13, 30],
    baseAmplitude: 15,
    amplitudeRange: [5, 30],
  }
};

function generateNoise(amplitude: number): number {
  return (Math.random() - 0.5) * 2 * amplitude;
}

function generateArtifact(t: number, type: 'blink' | 'muscle' | 'movement'): number {
  switch (type) {
    case 'blink':
      // Simulate eye blink artifact (sharp spike)
      return Math.exp(-Math.pow(t % 100 - 50, 2) / 50) * 100;
    case 'muscle':
      // Simulate muscle artifact (high frequency noise)
      return Math.sin(t * 0.5) * 20 + Math.random() * 15;
    case 'movement':
      // Simulate movement artifact (slow wave)
      return Math.sin(t * 0.02) * 30;
    default:
      return 0;
  }
}

function generateEEGData(waveType: string, duration: number = 1000) {
  const data = [];
  const params = EEG_PARAMETERS[waveType];
  
  if (!params) {
    throw new Error('Invalid wave type');
  }

  // Generate harmonics for more realistic signal
  const harmonics = [1, 0.5, 0.25]; // Fundamental frequency and harmonics
  let lastValue = 0; // For signal continuity

  // Artifact probability
  const artifactProb = 0.05;
  let isArtifact = false;
  let artifactType: 'blink' | 'muscle' | 'movement' = 'blink';

  for (let t = 0; t < duration; t++) {
    // Check for artifact generation
    if (Math.random() < artifactProb && !isArtifact) {
      isArtifact = true;
      artifactType = ['blink', 'muscle', 'movement'][Math.floor(Math.random() * 3)] as typeof artifactType;
    }
    
    // Base signal generation with harmonics
    let value = 0;
    harmonics.forEach((harmonic, i) => {
      const freq = params.baseFrequency * (i + 1);
      const phase = 2 * Math.PI * freq * t / 1000;
      value += harmonic * params.baseAmplitude * Math.sin(phase);
    });

    // Add frequency variation
    const freqMod = Math.sin(2 * Math.PI * 0.1 * t / 1000);
    value *= 1 + 0.1 * freqMod;

    // Add amplitude modulation
    const ampMod = 1 + 0.2 * Math.sin(2 * Math.PI * 0.05 * t / 1000);
    value *= ampMod;

    // Add physiological noise
    value += generateNoise(params.baseAmplitude * 0.1);

    // Add artifacts if active
    if (isArtifact) {
      value += generateArtifact(t, artifactType);
      if (t % 100 === 0) isArtifact = false; // Reset artifact after duration
    }

    // Signal smoothing
    value = value * 0.7 + lastValue * 0.3;
    lastValue = value;

    // Calculate signal quality (0-100%)
    const quality = isArtifact ? 
      Math.max(60, 100 - Math.abs(value) / 2) : 
      Math.max(85, 100 - Math.abs(value) / 4);

    data.push({ 
      time: t,
      value,
      frequency: params.baseFrequency + freqMod,
      amplitude: Math.abs(value),
      quality: Math.round(quality),
      hasArtifact: isArtifact,
      artifactType: isArtifact ? artifactType : null
    });
  }

  return data;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { waveType } = await req.json();
    const data = generateEEGData(waveType);

    return new Response(
      JSON.stringify({ 
        data,
        parameters: EEG_PARAMETERS[waveType],
        metadata: {
          samplingRate: 1000,
          duration: 1000,
          timestamp: new Date().toISOString()
        }
      }),
      { 
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 400,
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      }
    );
  }
});