import fs from 'fs';
import archiver from 'archiver';

const output = fs.createWriteStream('project.zip');
const archive = archiver('zip', {
  zlib: { level: 9 }
});

output.on('close', () => {
  console.log('Archive created successfully');
});

archive.on('error', (err) => {
  throw err;
});

archive.pipe(output);

// Add all project files except node_modules and .git
archive.glob('**/*', {
  ignore: ['node_modules/**', '.git/**', 'project.zip', 'download.js']
});

archive.finalize();