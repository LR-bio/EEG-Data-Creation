import React, { useState, useEffect } from 'react';
import { Brain, Activity, Settings2, Download, Play, Pause, RefreshCw, AlertTriangle, Zap } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, ReferenceLine, Tooltip } from 'recharts';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL ?? '',
  import.meta.env.VITE_SUPABASE_ANON_KEY ?? ''
);

function App() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedClass, setSelectedClass] = useState('alpha');
  const [eegData, setEegData] = useState([]);
  const [error, setError] = useState('');
  const [stats, setStats] = useState({
    avgAmplitude: 0,
    avgFrequency: 0,
    avgQuality: 100,
    artifactCount: 0
  });

  const eegClasses = ['alpha', 'beta', 'theta', 'delta'];

  useEffect(() => {
    let interval: number;
    
    if (isGenerating) {
      const fetchData = async () => {
        try {
          const { data, error } = await supabase.functions.invoke('generate-eeg', {
            body: { waveType: selectedClass }
          });

          if (error) throw error;

          // Calculate statistics
          const avgAmplitude = data.data.reduce((acc, point) => acc + Math.abs(point.amplitude), 0) / data.data.length;
          const avgFrequency = data.data.reduce((acc, point) => acc + point.frequency, 0) / data.data.length;
          const avgQuality = data.data.reduce((acc, point) => acc + point.quality, 0) / data.data.length;
          const artifactCount = data.data.filter(point => point.hasArtifact).length;

          setStats({
            avgAmplitude: Math.round(avgAmplitude * 10) / 10,
            avgFrequency: Math.round(avgFrequency * 10) / 10,
            avgQuality: Math.round(avgQuality),
            artifactCount
          });

          setEegData(data.data);
          setError('');
        } catch (err) {
          setError('Failed to generate EEG data');
          setIsGenerating(false);
        }
      };

      fetchData();
      interval = setInterval(fetchData, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isGenerating, selectedClass]);

  const handleExport = () => {
    const csvContent = "data:text/csv;charset=utf-8," + 
      "Time,Value,Frequency,Amplitude,Quality,HasArtifact,ArtifactType\n" + 
      eegData.map(point => 
        `${point.time},${point.value},${point.frequency},${point.amplitude},${point.quality},${point.hasArtifact},${point.artifactType || ''}`
      ).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `eeg_${selectedClass}_${new Date().toISOString()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-gray-800 p-3 rounded-lg shadow-lg border border-gray-700">
          <p className="text-blue-400">Time: {data.time}ms</p>
          <p className="text-white">Value: {Math.round(data.value * 100) / 100}µV</p>
          <p className="text-white">Frequency: {Math.round(data.frequency * 100) / 100}Hz</p>
          <p className="text-white">Quality: {data.quality}%</p>
          {data.hasArtifact && (
            <p className="text-yellow-400">Artifact: {data.artifactType}</p>
          )}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      <header className="border-b border-gray-700">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Brain className="w-8 h-8 text-blue-400" />
            <h1 className="text-2xl font-bold">Advanced EEG Signal Generator</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Control Panel */}
          <div className="bg-gray-800 rounded-lg p-6 shadow-xl">
            <div className="flex items-center space-x-2 mb-6">
              <Settings2 className="w-5 h-5 text-blue-400" />
              <h2 className="text-xl font-semibold">Controls</h2>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">EEG Class</label>
                <select
                  value={selectedClass}
                  onChange={(e) => setSelectedClass(e.target.value)}
                  className="w-full bg-gray-700 rounded-md px-3 py-2 text-white border border-gray-600 focus:border-blue-400 focus:ring focus:ring-blue-400 focus:ring-opacity-50"
                >
                  {eegClasses.map((cls) => (
                    <option key={cls} value={cls}>
                      {cls.charAt(0).toUpperCase() + cls.slice(1)} Waves
                    </option>
                  ))}
                </select>
              </div>

              <button
                onClick={() => setIsGenerating(!isGenerating)}
                className="w-full bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-md transition-colors flex items-center justify-center space-x-2"
              >
                {isGenerating ? (
                  <>
                    <Pause className="w-5 h-5" />
                    <span>Stop Generation</span>
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5" />
                    <span>Start Generation</span>
                  </>
                )}
              </button>

              <button 
                onClick={handleExport}
                disabled={!eegData.length}
                className="w-full bg-gray-700 hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium py-2 px-4 rounded-md transition-colors flex items-center justify-center space-x-2"
              >
                <Download className="w-5 h-5" />
                <span>Export Data</span>
              </button>

              {/* Signal Information */}
              <div className="mt-6 p-4 bg-gray-900 rounded-lg">
                <h3 className="text-sm font-medium text-gray-400 mb-3">Signal Information</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Wave Type:</span>
                    <span className="text-white font-medium">{selectedClass.toUpperCase()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Sampling Rate:</span>
                    <span className="text-white font-medium">1000 Hz</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Window Size:</span>
                    <span className="text-white font-medium">1000 ms</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Main Visualization */}
          <div className="lg:col-span-2 bg-gray-800 rounded-lg p-6 shadow-xl">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-2">
                <Activity className="w-5 h-5 text-blue-400" />
                <h2 className="text-xl font-semibold">Signal Visualization</h2>
              </div>
              {stats.artifactCount > 0 && (
                <div className="flex items-center space-x-2 text-yellow-400">
                  <AlertTriangle className="w-5 h-5" />
                  <span className="text-sm">{stats.artifactCount} artifacts detected</span>
                </div>
              )}
            </div>

            <div className="bg-gray-900 rounded-lg p-4 h-64">
              {error ? (
                <div className="h-full flex items-center justify-center text-red-400">
                  {error}
                </div>
              ) : eegData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={eegData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis 
                      dataKey="time"
                      stroke="#9CA3AF"
                      tick={{ fill: '#9CA3AF' }}
                      label={{ value: 'Time (ms)', position: 'bottom', fill: '#9CA3AF' }}
                    />
                    <YAxis
                      stroke="#9CA3AF"
                      tick={{ fill: '#9CA3AF' }}
                      label={{ value: 'Amplitude (µV)', angle: -90, position: 'left', fill: '#9CA3AF' }}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <ReferenceLine y={0} stroke="#4B5563" />
                    <Line
                      type="monotone"
                      dataKey="value"
                      stroke="#3B82F6"
                      dot={false}
                      strokeWidth={2}
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center text-gray-400">
                  Click "Start Generation" to begin
                </div>
              )}
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-4 gap-4 mt-6">
              <div className="bg-gray-900 rounded-lg p-4">
                <p className="text-sm text-gray-400">Avg. Frequency</p>
                <p className="text-xl font-semibold">{stats.avgFrequency} Hz</p>
              </div>
              <div className="bg-gray-900 rounded-lg p-4">
                <p className="text-sm text-gray-400">Avg. Amplitude</p>
                <p className="text-xl font-semibold">{stats.avgAmplitude} µV</p>
              </div>
              <div className="bg-gray-900 rounded-lg p-4">
                <p className="text-sm text-gray-400">Signal Quality</p>
                <p className="text-xl font-semibold">{stats.avgQuality}%</p>
              </div>
              <div className="bg-gray-900 rounded-lg p-4">
                <p className="text-sm text-gray-400">Artifacts</p>
                <p className="text-xl font-semibold flex items-center space-x-1">
                  <span>{stats.artifactCount}</span>
                  {stats.artifactCount > 0 && <Zap className="w-5 h-5 text-yellow-400" />}
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;